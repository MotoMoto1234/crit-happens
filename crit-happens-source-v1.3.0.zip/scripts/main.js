let MODULE_ID = "crit-happens";
let observedMessages = new WeakSet();
let soundedMessages = new WeakMap();
let receivedEvents = new Set();
let activeSounds = new Set();
let muteGeneration = 0;
let SOCKET = `module.${MODULE_ID}`;
let triggers = [
  { key: "natural1Sound", name: "Natural 1 sound (d20)", faces: 20, result: 1 },
  { key: "natural20Sound", name: "Natural 20 sound (d20)", faces: 20, result: 20 },
  { key: "natural100Sound", name: "Natural 100 sound (d100)", faces: 100, result: 100 }
];

Hooks.once("init", () => {
  game.settings.register(MODULE_ID, "muteSounds", {
    name: "Mute Crit Happens on this client",
    hint: "Silence all Crit Happens sounds for you, including your own rolls. Other players still hear your configured sounds. Useful when streaming. Does not mute other Foundry audio.",
    scope: "client",
    config: true,
    type: Boolean,
    default: false,
    onChange: async muted => {
      if (!muted) return;
      muteGeneration++;
      await Promise.allSettled([...activeSounds].map(sound => sound.stop()));
    }
  });
  for (let trigger of triggers) game.settings.register(MODULE_ID, trigger.key, {
    name: trigger.name,
    hint: "Choose an audio file or paste a Foundry-accessible path or URL. Your rolls broadcast this sound to everyone. Leave blank to disable this sound. Saved for this browser/client.",
    scope: "client",
    config: true,
    type: String,
    default: "",
    filePicker: "audio"
  });

  game.settings.register(MODULE_ID, "volume", {
    name: "Sound volume",
    hint: "Broadcast volume for your sounds. Each listener's Foundry Interface volume also applies.",
    scope: "client",
    config: true,
    type: Number,
    default: 0.8,
    range: { min: 0, max: 1, step: 0.05 }
  });
});

Hooks.once("ready", () => {
  game.socket.on(SOCKET, receiveSound);
});

async function receiveSound(data) {
  if (!data || typeof data.id !== "string" || typeof data.src !== "string"
    || !Number.isFinite(data.volume) || receivedEvents.has(data.id)) return;
  receivedEvents.add(data.id);
  if (receivedEvents.size > 1000) receivedEvents.delete(receivedEvents.values().next().value);
  if (game.settings.get(MODULE_ID, "muteSounds")) return;

  let sound;
  let generation = muteGeneration;
  try {
    sound = game.audio.create({ src: data.src, context: game.audio.interface, singleton: false });
    activeSounds.add(sound);
    sound.addEventListener("end", () => activeSounds.delete(sound), { once: true });
    sound.addEventListener("stop", () => activeSounds.delete(sound), { once: true });
    await sound.load();
    if (generation !== muteGeneration || game.settings.get(MODULE_ID, "muteSounds")) {
      activeSounds.delete(sound);
      return;
    }
    await sound.play({ volume: Math.max(0, Math.min(1, data.volume)), loop: false });
    if (generation !== muteGeneration || game.settings.get(MODULE_ID, "muteSounds")) await sound.stop();
  } catch (error) {
    activeSounds.delete(sound);
    console.error(`${MODULE_ID} | Could not play the configured sound.`, error);
    ui.notifications.warn("Crit Happens: Could not play the sound. Check the rolling player's configured filepath.");
  }
}

function hasResult(message, trigger) {
  return message.rolls.some(roll => roll.dice.some(die => {
    if (die.faces !== trigger.faces) return false;
    return die.results.some(result => result.active && !result.discarded
      && !result.rerolled && result.result === trigger.result);
  }));
}

async function playForMessage(message) {
  if (message.author?.id !== game.user.id || !message.isContentVisible) return;
  let sounded = soundedMessages.get(message) ?? new Set();
  soundedMessages.set(message, sounded);

  for (let trigger of triggers) {
    if (sounded.has(trigger.key) || !hasResult(message, trigger)) continue;
    let src = game.settings.get(MODULE_ID, trigger.key).trim();
    if (!src) continue;
    sounded.add(trigger.key);

    try {
      let data = {
        id: foundry.utils.randomID(),
        src,
        volume: game.settings.get(MODULE_ID, "volume")
      };
      game.socket.emit(SOCKET, data);
      await receiveSound(data);
    } catch (error) {
      console.error(`${MODULE_ID} | Could not play ${trigger.name}.`, error);
      ui.notifications.warn(`Crit Happens: Could not play ${trigger.name}. Check its filepath in Module Settings.`);
    }
  }
}

Hooks.on("createChatMessage", (message, options, userId) => {
  if (userId !== game.user.id) return;
  observedMessages.add(message);
  return playForMessage(message);
});

Hooks.on("updateChatMessage", (message, changes, options, userId) => {
  if (userId !== game.user.id || !observedMessages.has(message)) return;
  if (!Object.hasOwn(changes, "rolls")) return;
  return playForMessage(message);
});
